<footer>© 2014 <a href="http://www.1stwebdesigner.com/">1stwebdesigner</a>. All rights reserved. </footer>	
</body>
</html>
